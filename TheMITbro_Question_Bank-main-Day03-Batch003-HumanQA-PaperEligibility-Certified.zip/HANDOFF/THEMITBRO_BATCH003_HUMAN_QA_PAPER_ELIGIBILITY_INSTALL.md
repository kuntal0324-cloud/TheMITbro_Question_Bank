# Batch 003 Human-QA and Paper-Eligibility Installation

This package combines the already completed named-human QA evidence with its one-time paper-eligibility and Corpus V1 admission transition. It does not release or sell a paper.

## Required repository

Apply only to the current `main` branch of `TheMITbro_Question_Bank` after Question Bank PR #8 has been merged. Formatter PR #5 is already merged at `b695709`.

## Recommended branch

`gate-2027-ee-batch003-human-qa-certification`

## Package application

From `/workspaces/TheMITbro_Question_Bank`, verify the downloaded ZIP hash supplied beside the download, extract it into a temporary directory, copy the contents of `TheMITbro_Question_Bank-main/` over the repository root, and remove the uploaded ZIP before committing.

Do not copy the package's `HANDOFF/` directory into the repository. It contains the completed PDF evidence and these operator notes.

## Validation

```bash
python -m pip install -r requirements-pdf.txt

python scripts/validate_gate_ee_2027_contract.py
python scripts/validate_gate_ee_corpus_v1_foundation.py
python scripts/validate_gate_ee_batch_001.py
python scripts/validate_gate_ee_batch_001_paper_eligibility.py
python scripts/validate_gate_ee_batch_002.py
python scripts/recompute_gate_ee_batch_002.py --check
python scripts/validate_gate_ee_batch_002_human_signoff.py
python scripts/validate_gate_ee_batch_002_paper_eligibility.py
python scripts/validate_gate_ee_batch_002_pdf.py
python scripts/validate_gate_ee_batch_003.py
python scripts/recompute_gate_ee_batch_003.py --check
python scripts/validate_gate_ee_batch_003_human_signoff.py
python scripts/validate_gate_ee_batch_003_paper_eligibility.py
python scripts/validate_gate_ee_batch_003_pdf.py
python scripts/validate_gate_ee_eight_day_progress.py
git diff --check
```

Expected final state:

- Batch 003 human QA: 20 PASS / 0 REVISE / 0 REJECT
- Batch 003 paper-eligibility certification: PASS
- Corpus V1 admitted questions: 60
- Day 3 drafts: 0 / 447
- Eight-day sprint drafts: 40 / 3,575
- Program candidates / Formatter PASS: 60 / 60
- Paper-eligible / admitted: 60 / 60
- Complete / released papers: 0 / 0

The paper release gate must remain blocked because the exact 65-question Set 01 blueprint is incomplete.
